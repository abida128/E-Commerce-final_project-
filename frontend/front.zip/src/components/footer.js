import React from 'react';

function Footer() {
  return (
    <div className='p-10 text-center'>
      Footer content
    </div>
  );
}

export default Footer;
